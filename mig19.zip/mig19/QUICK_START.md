# 🚀 Quick Start - Angular 19 Migration

## Inicio Rápido

```bash
# 1. Navegar al proyecto
cd mig19

# 2. Instalar dependencias
npm install

# 3. Iniciar desarrollo
npm run start:web

# 4. Abrir en navegador
# http://localhost:4200
```

## Credenciales de Prueba

```
Usuario: admin@produbanco.com
Contraseña: admin123

Usuario: user@produbanco.com  
Contraseña: user123
```

## Rutas Disponibles

- `/login` - Login de usuario
- `/user` - Dashboard de usuario 
- `/admin` - Dashboard de administrador
- `/create-savings` - Crear cuenta de ahorros
- `/savings-accounts` - Listar cuentas
- `/error` - Página de error

## Arquitectura

```
mig19/
├── apps/web/           # SPA principal
├── libs/
│   ├── core/          # Auth, guards, interceptores
│   ├── shared/        # Componentes reutilizables  
│   ├── features/      # Páginas y características
│   └── data-access/   # Servicios API
```

## ✅ Migración Completa

- ✅ AngularJS 1.8 → Angular 19
- ✅ Standalone Components
- ✅ Angular Signals  
- ✅ Lazy Loading
- ✅ TypeScript Estricto
- ✅ Arquitectura Modular
- ✅ Principios SOLID

**¡Listo para desarrollo y producción!** 🎉
