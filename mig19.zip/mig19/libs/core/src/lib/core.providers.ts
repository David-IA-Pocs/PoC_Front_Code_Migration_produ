import { Provider, EnvironmentProviders } from "@angular/core";
import { provideHttpClient, withInterceptors } from "@angular/common/http";
import {
    API_BASE_URL,
    JWT_TOKEN_KEY,
    DEFAULT_APP_CONFIG,
} from "./tokens/app.tokens";
import { authInterceptor } from "./http/auth.interceptor";

/**
 * Core providers configuration
 * Centralized dependency injection setup
 */
export const coreProviders: (Provider | EnvironmentProviders)[] = [
    // HTTP Client with interceptors
    provideHttpClient(withInterceptors([authInterceptor])),

    // App configuration tokens
    {
        provide: API_BASE_URL,
        useValue: DEFAULT_APP_CONFIG.apiBaseUrl,
    },
    {
        provide: JWT_TOKEN_KEY,
        useValue: DEFAULT_APP_CONFIG.jwtTokenKey,
    },
];
