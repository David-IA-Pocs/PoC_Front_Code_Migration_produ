import { InjectionToken } from "@angular/core";

/**
 * API Configuration tokens
 */
export const API_BASE_URL = new InjectionToken<string>("API_BASE_URL");

/**
 * Storage keys tokens
 */
export const JWT_TOKEN_KEY = new InjectionToken<string>("JWT_TOKEN_KEY");

/**
 * Application configuration tokens
 */
export const APP_CONFIG = new InjectionToken<AppConfig>("APP_CONFIG");

export interface AppConfig {
    production: boolean;
    apiBaseUrl: string;
    jwtTokenKey: string;
}

/**
 * Default configuration values
 */
export const DEFAULT_APP_CONFIG: AppConfig = {
    production: false,
    apiBaseUrl: "https://zwhf4xnv-5000.use2.devtunnels.ms",
    jwtTokenKey: "jwt_token",
};
