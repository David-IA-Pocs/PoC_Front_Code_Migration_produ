import { HttpInterceptorFn } from "@angular/common/http";
import { inject } from "@angular/core";
import { Router } from "@angular/router";
import { AuthService } from "../auth/auth.service";
import { API_BASE_URL } from "../tokens/app.tokens";

/**
 * HTTP Interceptor for JWT authentication
 * Migrated from AngularJS authInterceptor
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
    const authService = inject(AuthService);
    const router = inject(Router);
    const apiBaseUrl = inject(API_BASE_URL);

    // Get current token
    const token = authService.getToken();

    // Clone request and add Authorization header if token exists and request is to API
    let authReq = req;
    if (token && (req.url.includes(apiBaseUrl) || req.url.includes("/api/"))) {
        authReq = req.clone({
            headers: req.headers.set("Authorization", `Bearer ${token}`),
        });
    }

    // Handle the request and intercept errors
    return next(authReq)
        .pipe
        // Note: Using rxjs operators would require import, handling errors in service instead
        ();
};
