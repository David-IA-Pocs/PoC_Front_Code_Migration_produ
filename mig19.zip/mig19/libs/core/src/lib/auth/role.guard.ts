import { inject } from "@angular/core";
import { CanActivateFn, Router, ActivatedRouteSnapshot } from "@angular/router";
import { AuthService } from "./auth.service";

/**
 * Role-based authorization guard
 * Migrated from AngularJS route resolvers with role checking
 */
export const roleGuard: CanActivateFn = (
    route: ActivatedRouteSnapshot,
    state
) => {
    const authService = inject(AuthService);
    const router = inject(Router);

    const expectedRole = route.data?.["expectedRole"] as string;
    const userRole = authService.userRole();

    if (!expectedRole) {
        // No role requirement
        return true;
    }

    if (userRole === expectedRole) {
        return true;
    }

    // Redirect to error page if role doesn't match
    router.navigate(["/error"]);
    return false;
};
