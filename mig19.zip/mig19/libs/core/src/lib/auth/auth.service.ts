import { inject, Injectable, signal, computed } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";
import { Observable, BehaviorSubject, throwError } from "rxjs";
import { map, catchError, tap } from "rxjs/operators";
import { API_BASE_URL, JWT_TOKEN_KEY } from "../tokens/app.tokens";

export interface LoginCredentials {
    username: string;
    password: string;
}

export interface LoginResponse {
    token: string;
    type: string;
    id: number;
    username: string;
    email: string;
    role: string;
}

export interface UserInfo {
    username: string;
    email: string;
    role: string;
    id: string;
    exp: number;
    iat?: number;
}

/**
 * Authentication service using Angular Signals for state management
 * Migrated from AngularJS authService with modern Angular patterns
 */
@Injectable({
    providedIn: "root",
})
export class AuthService {
    private readonly http = inject(HttpClient);
    private readonly router = inject(Router);
    private readonly apiBaseUrl = inject(API_BASE_URL);
    private readonly jwtTokenKey = inject(JWT_TOKEN_KEY);

    // Signals for reactive state management
    private readonly _isAuthenticated = signal(false);
    private readonly _userInfo = signal<UserInfo | null>(null);
    private readonly _userRole = signal<string | null>(null);

    // Public readonly signals
    readonly isAuthenticated = this._isAuthenticated.asReadonly();
    readonly userInfo = this._userInfo.asReadonly();
    readonly userRole = this._userRole.asReadonly();

    // Computed signals
    readonly isUser = computed(() => this._userRole() === "User");
    readonly isAdmin = computed(() => this._userRole() === "Admin");

    constructor() {
        this.initializeAuth();
    }

    /**
     * Initialize authentication state from stored token
     */
    private initializeAuth(): void {
        const token = this.getStoredToken();
        if (token && this.validateToken(token)) {
            this.setAuthState(token);
        } else {
            this.clearAuthState();
        }
    }

    /**
     * Perform user login
     */
    login(credentials: LoginCredentials): Observable<LoginResponse> {
        return this.http
            .post<LoginResponse>(
                `${this.apiBaseUrl}/api/auth/signin`,
                credentials
            )
            .pipe(
                tap((response) => {
                    if (response?.token) {
                        this.setStoredToken(response.token);
                        this.setAuthState(response.token);
                    }
                }),
                catchError((error) => {
                    console.error("Login error:", error);
                    return throwError(
                        () => error?.data || "Error de autenticación"
                    );
                })
            );
    }

    /**
     * Perform user logout
     */
    logout(): void {
        this.clearStoredToken();
        this.clearAuthState();
        this.router.navigate(["/login"]);
    }

    /**
     * Get current JWT token
     */
    getToken(): string | null {
        return this.getStoredToken();
    }

    /**
     * Check if current token is valid
     */
    private validateToken(token: string): boolean {
        try {
            const payload = this.parseJWT(token);

            // Check if token is expired
            if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
                return false;
            }

            return true;
        } catch (error) {
            console.error("Error validating token:", error);
            return false;
        }
    }

    /**
     * Set authentication state from token
     */
    private setAuthState(token: string): void {
        try {
            const payload = this.parseJWT(token);
            const userInfo: UserInfo = {
                username:
                    payload[
                        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"
                    ],
                email: payload[
                    "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"
                ],
                role: payload[
                    "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"
                ],
                id: payload[
                    "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"
                ],
                exp: payload.exp,
                iat: payload.iat,
            };

            this._isAuthenticated.set(true);
            this._userInfo.set(userInfo);
            this._userRole.set(userInfo.role);
        } catch (error) {
            console.error("Error setting auth state:", error);
            this.clearAuthState();
        }
    }

    /**
     * Clear authentication state
     */
    private clearAuthState(): void {
        this._isAuthenticated.set(false);
        this._userInfo.set(null);
        this._userRole.set(null);
    }

    /**
     * Parse JWT token payload
     */
    private parseJWT(token: string): any {
        try {
            const parts = token.split(".");
            if (parts.length !== 3) {
                throw new Error("Invalid JWT token");
            }

            let payload = parts[1];

            // Decode base64url
            payload = payload.replace(/-/g, "+").replace(/_/g, "/");

            // Add padding if necessary
            switch (payload.length % 4) {
                case 0:
                    break;
                case 2:
                    payload += "==";
                    break;
                case 3:
                    payload += "=";
                    break;
                default:
                    throw new Error("Malformed JWT token");
            }

            const decoded = atob(payload);
            return JSON.parse(decoded);
        } catch (error) {
            throw new Error(`Error decoding JWT: ${error}`);
        }
    }

    /**
     * Get token from localStorage
     */
    private getStoredToken(): string | null {
        try {
            return localStorage.getItem(this.jwtTokenKey);
        } catch (error) {
            console.error("Error getting stored token:", error);
            return null;
        }
    }

    /**
     * Store token in localStorage
     */
    private setStoredToken(token: string): void {
        try {
            localStorage.setItem(this.jwtTokenKey, token);
        } catch (error) {
            console.error("Error storing token:", error);
        }
    }

    /**
     * Remove token from localStorage
     */
    private clearStoredToken(): void {
        try {
            localStorage.removeItem(this.jwtTokenKey);
        } catch (error) {
            console.error("Error clearing token:", error);
        }
    }
}
