import {
    Component,
    Input,
    Output,
    EventEmitter,
    computed,
    inject,
    signal,
} from "@angular/core";
import { CommonModule } from "@angular/common";
import { Router } from "@angular/router";
import { AuthService } from "@core/auth/auth.service";

/**
 * Navigation Bar Component
 * Migrated from AngularJS navController with Angular Signals
 */
@Component({
    selector: "app-navbar",
    standalone: true,
    imports: [CommonModule],
    template: `
        @if (!isLoginPage()) {
            <nav class="navbar">
                <div class="nav-content">
                    <div class="logo" (click)="navigateToHome()">
                        <img
                            src="assets/image.png"
                            alt="Produbanco"
                            class="logo-img"
                        />
                    </div>

                    @if (authService.isAuthenticated()) {
                        <div class="nav-links">
                            <span class="user-info">
                                Bienvenido,
                                {{ getUserRoleDisplay(authService.userRole()) }}
                            </span>
                            <button class="btn btn-logout" (click)="logout()">
                                Cerrar Sesión
                            </button>
                        </div>
                    }
                </div>
            </nav>
        }
    `,
    styles: [
        `
            .navbar {
                background: var(--surface-primary);
                color: var(--text-primary);
                padding: var(--spacing-md) 0;
                box-shadow: var(--shadow-light);
                border-bottom: 1px solid var(--border-light);
                position: sticky;
                top: 0;
                z-index: var(--z-sticky);
            }

            .nav-content {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 var(--spacing-xl);
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .logo {
                display: flex;
                align-items: center;
                gap: var(--spacing-md);
                cursor: pointer;
                transition: opacity var(--transition-normal);
            }

            .logo:hover {
                opacity: 0.8;
            }

            .logo-img {
                height: 40px;
                width: auto;
                max-width: 200px;
                object-fit: contain;
            }

            .nav-links {
                display: flex;
                align-items: center;
                gap: var(--spacing-lg);
            }

            .user-info {
                color: var(--text-secondary);
                font-size: var(--font-size-sm);
                font-weight: var(--font-weight-medium);
            }

            .btn-logout {
                background: transparent;
                color: var(--primary-color);
                border: 2px solid var(--primary-color);
                border-radius: var(--border-radius-medium);
                padding: var(--spacing-sm) var(--spacing-md);
                font-size: var(--font-size-sm);
                font-weight: var(--font-weight-medium);
                cursor: pointer;
                transition: all var(--transition-normal);
            }

            .btn-logout:hover {
                background: var(--primary-color);
                color: var(--text-on-primary);
                transform: translateY(-1px);
            }

            .btn-logout:focus {
                outline: none;
                box-shadow: 0 0 0 3px rgba(0, 176, 79, 0.2);
            }

            /* Responsive design */
            @media (max-width: 768px) {
                .nav-content {
                    padding: 0 var(--spacing-md);
                }

                .user-info {
                    display: none;
                }

                .nav-links {
                    gap: var(--spacing-md);
                }
            }
        `,
    ],
})
export class NavbarComponent {
    protected readonly authService = inject(AuthService);
    private readonly router = inject(Router);

    // Signal to track if current page is login
    private currentPath = signal(this.router.url);

    // Computed signal to determine if it's login page
    protected isLoginPage = computed(() => {
        const path = this.currentPath();
        return path === "/login" || path === "/";
    });

    constructor() {
        // Listen to router events to update current path
        this.router.events.subscribe(() => {
            this.currentPath.set(this.router.url);
        });
    }

    /**
     * Handle user logout
     */
    logout(): void {
        this.authService.logout();
    }

    /**
     * Navigate to appropriate home based on user role
     */
    navigateToHome(): void {
        if (this.authService.isAuthenticated()) {
            const role = this.authService.userRole();
            if (role === "Admin") {
                this.router.navigate(["/admin"]);
            } else {
                this.router.navigate(["/user"]);
            }
        } else {
            this.router.navigate(["/login"]);
        }
    }

    /**
     * Get display text for user role
     */
    protected getUserRoleDisplay(role: string | null): string {
        switch (role) {
            case "User":
                return "Usuario";
            case "Admin":
                return "Administrador";
            default:
                return "";
        }
    }
}
