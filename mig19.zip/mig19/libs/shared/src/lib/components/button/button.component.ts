import { Component, Input, Output, EventEmitter } from "@angular/core";
import { CommonModule } from "@angular/common";

export type ButtonVariant =
    | "primary"
    | "secondary"
    | "outline"
    | "text"
    | "danger";
export type ButtonSize = "small" | "medium" | "large";

/**
 * Reusable Button Component
 * Stand-alone component following DRY principles
 */
@Component({
    selector: "app-button",
    standalone: true,
    imports: [CommonModule],
    template: `
        <button
            [type]="type"
            [disabled]="disabled || loading"
            [class]="buttonClasses"
            (click)="handleClick($event)"
        >
            @if (loading) {
                <span class="loading-spinner" aria-hidden="true"></span>
            }

            @if (iconLeft && !loading) {
                <span class="icon icon-left" [innerHTML]="iconLeft"></span>
            }

            <span class="button-text">
                <ng-content></ng-content>
            </span>

            @if (iconRight && !loading) {
                <span class="icon icon-right" [innerHTML]="iconRight"></span>
            }
        </button>
    `,
    styles: [
        `
            .btn {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                gap: var(--spacing-sm);
                font-family: inherit;
                font-weight: var(--font-weight-medium);
                text-decoration: none;
                border: 2px solid transparent;
                border-radius: var(--border-radius-medium);
                cursor: pointer;
                transition: all var(--transition-normal);
                position: relative;
                white-space: nowrap;
                user-select: none;
            }

            .btn:focus {
                outline: none;
                box-shadow: 0 0 0 3px rgba(0, 176, 79, 0.2);
            }

            .btn:disabled {
                opacity: 0.6;
                cursor: not-allowed;
                pointer-events: none;
            }

            /* Sizes */
            .btn-small {
                padding: var(--spacing-sm) var(--spacing-md);
                font-size: var(--font-size-sm);
                min-height: 36px;
            }

            .btn-medium {
                padding: var(--spacing-md) var(--spacing-lg);
                font-size: var(--font-size-base);
                min-height: 44px;
            }

            .btn-large {
                padding: var(--spacing-lg) var(--spacing-xl);
                font-size: var(--font-size-lg);
                min-height: 52px;
            }

            /* Variants */
            .btn-primary {
                background: var(--primary-color);
                color: var(--text-on-primary);
                border-color: var(--primary-color);
            }

            .btn-primary:hover:not(:disabled) {
                background: var(--primary-color-dark);
                border-color: var(--primary-color-dark);
                transform: translateY(-1px);
            }

            .btn-secondary {
                background: var(--secondary-color);
                color: var(--text-on-primary);
                border-color: var(--secondary-color);
            }

            .btn-secondary:hover:not(:disabled) {
                background: var(--color-azul-oscuro, #002244);
                border-color: var(--color-azul-oscuro, #002244);
                transform: translateY(-1px);
            }

            .btn-outline {
                background: transparent;
                color: var(--primary-color);
                border-color: var(--primary-color);
            }

            .btn-outline:hover:not(:disabled) {
                background: var(--primary-color);
                color: var(--text-on-primary);
            }

            .btn-text {
                background: transparent;
                color: var(--primary-color);
                border-color: transparent;
                padding-left: var(--spacing-sm);
                padding-right: var(--spacing-sm);
            }

            .btn-text:hover:not(:disabled) {
                background: var(--primary-color-light);
            }

            .btn-danger {
                background: var(--color-error);
                color: var(--text-on-primary);
                border-color: var(--color-error);
            }

            .btn-danger:hover:not(:disabled) {
                background: #c82333;
                border-color: #c82333;
                transform: translateY(-1px);
            }

            /* Loading state */
            .loading-spinner {
                width: 16px;
                height: 16px;
                border: 2px solid transparent;
                border-top: 2px solid currentColor;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }

            @keyframes spin {
                0% {
                    transform: rotate(0deg);
                }
                100% {
                    transform: rotate(360deg);
                }
            }

            .icon {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .icon svg {
                width: 16px;
                height: 16px;
                fill: currentColor;
            }

            .button-text {
                line-height: 1;
            }
        `,
    ],
})
export class ButtonComponent {
    @Input() variant: ButtonVariant = "primary";
    @Input() size: ButtonSize = "medium";
    @Input() type: "button" | "submit" | "reset" = "button";
    @Input() disabled = false;
    @Input() loading = false;
    @Input() iconLeft?: string;
    @Input() iconRight?: string;
    @Input() fullWidth = false;

    @Output() clicked = new EventEmitter<Event>();

    get buttonClasses(): string {
        const classes = ["btn", `btn-${this.variant}`, `btn-${this.size}`];

        if (this.fullWidth) {
            classes.push("btn-full-width");
        }

        return classes.join(" ");
    }

    handleClick(event: Event): void {
        if (!this.disabled && !this.loading) {
            this.clicked.emit(event);
        }
    }
}
