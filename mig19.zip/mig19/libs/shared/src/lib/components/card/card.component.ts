import { Component, Input } from "@angular/core";
import { CommonModule } from "@angular/common";

export type CardVariant = "default" | "elevated" | "outlined";

/**
 * Reusable Card Component
 * Stand-alone component for consistent card layouts
 */
@Component({
    selector: "app-card",
    standalone: true,
    imports: [CommonModule],
    template: `
        <div [class]="cardClasses">
            @if (header) {
                <div class="card-header">
                    @if (headerIcon) {
                        <span
                            class="header-icon"
                            [innerHTML]="headerIcon"
                        ></span>
                    }
                    <h3 class="header-title">{{ header }}</h3>
                    @if (headerSubtitle) {
                        <p class="header-subtitle">{{ headerSubtitle }}</p>
                    }
                </div>
            }

            <div class="card-content">
                <ng-content></ng-content>
            </div>

            @if (hasFooter) {
                <div class="card-footer">
                    <ng-content select="[slot=footer]"></ng-content>
                </div>
            }
        </div>
    `,
    styles: [
        `
            .card {
                background: var(--surface-primary);
                border-radius: var(--border-radius-medium);
                overflow: hidden;
                transition: all var(--transition-normal);
            }

            .card-default {
                border: 1px solid var(--border-light);
                box-shadow: var(--shadow-light);
            }

            .card-elevated {
                border: none;
                box-shadow: var(--shadow-medium);
            }

            .card-elevated:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 32px var(--shadow-medium);
            }

            .card-outlined {
                border: 2px solid var(--border-medium);
                box-shadow: none;
            }

            .card-header {
                padding: var(--spacing-lg);
                border-bottom: 1px solid var(--border-light);
                background: var(--background-secondary);
                display: flex;
                align-items: center;
                gap: var(--spacing-md);
            }

            .header-icon {
                display: flex;
                align-items: center;
                justify-content: center;
                width: 40px;
                height: 40px;
                background: var(--primary-color);
                border-radius: var(--border-radius-medium);
                color: var(--text-on-primary);
            }

            .header-icon svg {
                width: 20px;
                height: 20px;
                fill: currentColor;
            }

            .header-title {
                margin: 0;
                font-size: var(--font-size-lg);
                font-weight: var(--font-weight-semibold);
                color: var(--text-primary);
                line-height: var(--line-height-tight);
            }

            .header-subtitle {
                margin: 0;
                font-size: var(--font-size-sm);
                color: var(--text-secondary);
                line-height: var(--line-height-normal);
            }

            .card-content {
                padding: var(--spacing-lg);
            }

            .card-footer {
                padding: var(--spacing-lg);
                border-top: 1px solid var(--border-light);
                background: var(--background-secondary);
            }

            /* Responsive adjustments */
            @media (max-width: 768px) {
                .card-header,
                .card-content,
                .card-footer {
                    padding: var(--spacing-md);
                }
            }
        `,
    ],
})
export class CardComponent {
    @Input() variant: CardVariant = "default";
    @Input() header?: string;
    @Input() headerSubtitle?: string;
    @Input() headerIcon?: string;
    @Input() hasFooter = false;

    get cardClasses(): string {
        return `card card-${this.variant}`;
    }
}
