import { Component, Input, Output, EventEmitter, signal } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";

export type InputType = "text" | "email" | "password" | "number" | "tel";

/**
 * Reusable Input Component
 * Stand-alone component with validation and accessibility
 */
@Component({
    selector: "app-input",
    standalone: true,
    imports: [CommonModule, FormsModule],
    template: `
        <div class="form-group" [class.has-error]="hasError && touched()">
            @if (label) {
                <label [for]="inputId" class="form-label">
                    {{ label }}
                    @if (required) {
                        <span class="required-asterisk" aria-label="required"
                            >*</span
                        >
                    }
                </label>
            }

            <div class="input-wrapper">
                <input
                    [id]="inputId"
                    [type]="type"
                    [value]="value"
                    [placeholder]="placeholder"
                    [required]="required"
                    [disabled]="disabled"
                    [readonly]="readonly"
                    [attr.minlength]="minLength || null"
                    [attr.maxlength]="maxLength || null"
                    [min]="min || undefined"
                    [max]="max || undefined"
                    [autocomplete]="autocomplete"
                    class="form-control"
                    (input)="onInput($event)"
                    (focus)="onFocus()"
                    (blur)="onBlur()"
                />

                @if (iconLeft) {
                    <span
                        class="input-icon input-icon-left"
                        [innerHTML]="iconLeft"
                    ></span>
                }

                @if (iconRight) {
                    <span
                        class="input-icon input-icon-right"
                        [innerHTML]="iconRight"
                    ></span>
                }
            </div>

            @if (errorMessage && hasError && touched()) {
                <span class="error-text">{{ errorMessage }}</span>
            }

            @if (helpText && (!hasError || !touched())) {
                <span class="help-text">{{ helpText }}</span>
            }
        </div>
    `,
    styles: [
        `
            .form-group {
                margin-bottom: var(--spacing-lg);
            }

            .form-label {
                display: block;
                font-weight: var(--font-weight-medium);
                color: var(--text-primary);
                margin-bottom: var(--spacing-sm);
                font-size: var(--font-size-sm);
            }

            .required-asterisk {
                color: var(--color-error);
                margin-left: var(--spacing-xs);
            }

            .input-wrapper {
                position: relative;
                display: flex;
                align-items: center;
            }

            .form-control {
                width: 100%;
                padding: var(--spacing-md) var(--spacing-md);
                font-size: var(--font-size-base);
                font-family: inherit;
                line-height: var(--line-height-normal);
                color: var(--text-primary);
                background-color: var(--surface-primary);
                border: 2px solid var(--border-light);
                border-radius: var(--border-radius-medium);
                transition: all var(--transition-normal);
                min-height: 44px;
            }

            .form-control:focus {
                outline: none;
                border-color: var(--primary-color);
                box-shadow: 0 0 0 3px rgba(0, 176, 79, 0.1);
            }

            .form-control:disabled {
                background-color: var(--background-secondary);
                color: var(--text-secondary);
                cursor: not-allowed;
                opacity: 0.6;
            }

            .form-control:readonly {
                background-color: var(--background-secondary);
                cursor: default;
            }

            .form-control::placeholder {
                color: var(--text-secondary);
                opacity: 1;
            }

            /* Input with icons */
            .input-wrapper:has(.input-icon-left) .form-control {
                padding-left: 44px;
            }

            .input-wrapper:has(.input-icon-right) .form-control {
                padding-right: 44px;
            }

            .input-icon {
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                color: var(--text-secondary);
                display: flex;
                align-items: center;
                justify-content: center;
                width: 20px;
                height: 20px;
                pointer-events: none;
            }

            .input-icon-left {
                left: var(--spacing-md);
            }

            .input-icon-right {
                right: var(--spacing-md);
            }

            .input-icon svg {
                width: 16px;
                height: 16px;
                fill: currentColor;
            }

            /* Error state */
            .has-error .form-control {
                border-color: var(--color-error);
                box-shadow: 0 0 0 3px rgba(220, 53, 69, 0.1);
            }

            .has-error .form-label {
                color: var(--color-error);
            }

            .error-text {
                display: block;
                color: var(--color-error);
                font-size: var(--font-size-xs);
                margin-top: var(--spacing-xs);
                line-height: var(--line-height-normal);
            }

            .help-text {
                display: block;
                color: var(--text-secondary);
                font-size: var(--font-size-xs);
                margin-top: var(--spacing-xs);
                line-height: var(--line-height-normal);
            }

            /* Focus within for better UX */
            .form-group:focus-within .form-label {
                color: var(--primary-color);
            }
        `,
    ],
})
export class InputComponent {
    @Input() inputId = `input-${Math.random().toString(36).substring(2, 15)}`;
    @Input() type: InputType = "text";
    @Input() label?: string;
    @Input() placeholder?: string;
    @Input() value = "";
    @Input() required = false;
    @Input() disabled = false;
    @Input() readonly = false;
    @Input() minLength?: number;
    @Input() maxLength?: number;
    @Input() min?: number;
    @Input() max?: number;
    @Input() autocomplete = "off";
    @Input() iconLeft?: string;
    @Input() iconRight?: string;
    @Input() errorMessage?: string;
    @Input() helpText?: string;
    @Input() hasError = false;

    @Output() valueChange = new EventEmitter<string>();
    @Output() inputFocus = new EventEmitter<void>();
    @Output() inputBlur = new EventEmitter<void>();

    // Track if input has been touched
    touched = signal(false);

    onInput(event: Event): void {
        const target = event.target as HTMLInputElement;
        this.valueChange.emit(target.value);
    }

    onFocus(): void {
        this.inputFocus.emit();
    }

    onBlur(): void {
        this.touched.set(true);
        this.inputBlur.emit();
    }
}
