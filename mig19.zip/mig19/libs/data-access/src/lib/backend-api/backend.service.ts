import { Injectable, inject } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs/operators";
import { API_BASE_URL } from "@core/tokens/app.tokens";

export interface HealthResponse {
    status: string;
    timestamp: string;
}

export interface TestResponse {
    message: string;
}

/**
 * Backend Service for health checks and testing
 * Migrated from AngularJS backendService
 */
@Injectable({
    providedIn: "root",
})
export class BackendService {
    private readonly http = inject(HttpClient);
    private readonly apiBaseUrl = inject(API_BASE_URL);

    /**
     * Check backend health status
     */
    checkHealth(): Observable<HealthResponse> {
        return this.http.get<HealthResponse>(`${this.apiBaseUrl}/health`).pipe(
            catchError((error) => {
                console.error("Health check failed:", error);
                return throwError(() => error);
            })
        );
    }

    /**
     * Test user access to protected endpoint
     */
    testUserAccess(): Observable<TestResponse> {
        return this.http
            .get<TestResponse>(`${this.apiBaseUrl}/api/test/user`)
            .pipe(
                catchError((error) => {
                    console.error("User access test failed:", error);
                    return throwError(() => error);
                })
            );
    }

    /**
     * Test admin access to protected endpoint
     */
    testAdminAccess(): Observable<TestResponse> {
        return this.http
            .get<TestResponse>(`${this.apiBaseUrl}/api/test/admin`)
            .pipe(
                catchError((error) => {
                    console.error("Admin access test failed:", error);
                    return throwError(() => error);
                })
            );
    }
}
