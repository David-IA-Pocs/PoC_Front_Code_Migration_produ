import { Injectable, inject } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs/operators";
import { API_BASE_URL } from "@core/tokens/app.tokens";

export interface SavingsAccountData {
    titularName: string;
    identificationNumber: string;
    identificationType: string;
    phoneNumber: string;
    address: string;
    initialDeposit: number;
}

export interface SavingsAccount {
    id: string;
    accountNumber: string;
    titularName: string;
    identificationNumber: string;
    identificationType: string;
    phoneNumber: string;
    address: string;
    initialDeposit: number;
    status: string;
    createdDate: string;
}

export interface CreateSavingsResponse {
    account: SavingsAccount;
    message: string;
}

export interface GetAccountsResponse {
    accounts: SavingsAccount[];
    total: number;
}

/**
 * Savings Service for account management
 * Migrated from AngularJS savingsService
 */
@Injectable({
    providedIn: "root",
})
export class SavingsService {
    private readonly http = inject(HttpClient);
    private readonly apiBaseUrl = inject(API_BASE_URL);

    /**
     * Create a new savings account
     */
    createSavingsAccount(
        accountData: SavingsAccountData
    ): Observable<CreateSavingsResponse> {
        return this.http
            .post<CreateSavingsResponse>(
                `${this.apiBaseUrl}/api/savings-account/create`,
                accountData
            )
            .pipe(
                catchError((error) => {
                    console.error("Error creating savings account:", error);
                    return throwError(() => error);
                })
            );
    }

    /**
     * Get user's savings accounts
     */
    getMyAccounts(): Observable<GetAccountsResponse> {
        return this.http
            .get<GetAccountsResponse>(
                `${this.apiBaseUrl}/api/savings-account/my-accounts`
            )
            .pipe(
                catchError((error) => {
                    console.error("Error getting savings accounts:", error);
                    return throwError(() => error);
                })
            );
    }
}
