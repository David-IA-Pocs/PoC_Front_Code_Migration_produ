import { Component, inject, signal } from "@angular/core";
import { CommonModule } from "@angular/common";
import { Router, ActivatedRoute } from "@angular/router";
import { AuthService } from "@core/auth/auth.service";
import { CardComponent } from "@shared/components/card/card.component";
import { ButtonComponent } from "@shared/components/button/button.component";

/**
 * Error Component
 * Migrated from AngularJS ErrorController with Angular Signals
 */
@Component({
    selector: "app-error",
    standalone: true,
    imports: [CommonModule, CardComponent, ButtonComponent],
    template: `
        <div class="error-container">
            <app-card variant="elevated" class="error-card">
                <div class="error-content">
                    <!-- Error Icon -->
                    <div class="error-icon">
                        <svg viewBox="0 0 24 24">
                            <path
                                d="M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z"
                            />
                        </svg>
                    </div>

                    <!-- Error Title -->
                    <h1 class="error-title">Acceso No Autorizado</h1>

                    <!-- Error Message -->
                    <p class="error-message">{{ errorMessage() }}</p>

                    <!-- Error Details -->
                    <div class="error-details">
                        <p>Posibles causas:</p>
                        <ul>
                            <li>
                                No tienes permisos suficientes para acceder a
                                esta página
                            </li>
                            <li>Tu sesión ha expirado</li>
                            <li>
                                Se produjo un error inesperado en el sistema
                            </li>
                        </ul>
                    </div>

                    <!-- Actions -->
                    <div class="error-actions">
                        @if (canGoBack()) {
                            <app-button
                                variant="outline"
                                size="large"
                                (clicked)="goBack()"
                            >
                                Volver Atrás
                            </app-button>
                        }

                        <app-button
                            variant="primary"
                            size="large"
                            (clicked)="goToLogin()"
                        >
                            Ir al Login
                        </app-button>
                    </div>

                    <!-- Additional Help -->
                    <div class="error-help">
                        <p class="help-text">
                            Si el problema persiste, contacta al administrador
                            del sistema.
                        </p>
                    </div>
                </div>
            </app-card>
        </div>
    `,
    styles: [
        `
            .error-container {
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: var(--spacing-xl);
                background: var(--background-primary);
            }

            .error-card {
                max-width: 600px;
                width: 100%;
            }

            .error-content {
                text-align: center;
            }

            .error-icon {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 80px;
                height: 80px;
                background: rgba(220, 53, 69, 0.1);
                border: 2px solid var(--color-error);
                border-radius: 50%;
                margin-bottom: var(--spacing-xl);
            }

            .error-icon svg {
                width: 40px;
                height: 40px;
                fill: var(--color-error);
            }

            .error-title {
                font-size: var(--font-size-3xl);
                font-weight: var(--font-weight-bold);
                color: var(--text-primary);
                margin-bottom: var(--spacing-lg);
                line-height: var(--line-height-tight);
            }

            .error-message {
                font-size: var(--font-size-lg);
                color: var(--text-secondary);
                margin-bottom: var(--spacing-xl);
                line-height: var(--line-height-relaxed);
            }

            .error-details {
                background: var(--background-secondary);
                border: 1px solid var(--border-light);
                border-radius: var(--border-radius-medium);
                padding: var(--spacing-lg);
                margin-bottom: var(--spacing-xl);
                text-align: left;
            }

            .error-details p {
                font-weight: var(--font-weight-semibold);
                color: var(--text-primary);
                margin-bottom: var(--spacing-md);
            }

            .error-details ul {
                margin: 0;
                padding-left: var(--spacing-lg);
                color: var(--text-secondary);
            }

            .error-details li {
                margin-bottom: var(--spacing-sm);
                line-height: var(--line-height-relaxed);
            }

            .error-actions {
                display: flex;
                justify-content: center;
                gap: var(--spacing-lg);
                margin-bottom: var(--spacing-xl);
                flex-wrap: wrap;
            }

            .error-help {
                padding-top: var(--spacing-lg);
                border-top: 1px solid var(--border-light);
            }

            .help-text {
                font-size: var(--font-size-sm);
                color: var(--text-secondary);
                margin: 0;
                line-height: var(--line-height-relaxed);
            }

            /* Responsive design */
            @media (max-width: 768px) {
                .error-container {
                    padding: var(--spacing-lg);
                }

                .error-title {
                    font-size: var(--font-size-2xl);
                }

                .error-message {
                    font-size: var(--font-size-base);
                }

                .error-actions {
                    flex-direction: column;
                    align-items: center;
                }

                .error-actions app-button {
                    width: 100%;
                    max-width: 250px;
                }
            }
        `,
    ],
})
export class ErrorComponent {
    private readonly authService = inject(AuthService);
    private readonly router = inject(Router);
    private readonly route = inject(ActivatedRoute);

    // Component state using signals
    protected readonly errorMessage = signal(
        "Acceso no autorizado o error inesperado"
    );
    protected readonly canGoBack = signal(false);

    constructor() {
        this.initialize();
    }

    /**
     * Initialize component state
     */
    private initialize(): void {
        // Check if there's a previous page to go back to
        this.canGoBack.set(window.history.length > 1);

        // Get error message from route data or query params if available
        const routeError = this.route.snapshot.data?.["error"];
        const queryError = this.route.snapshot.queryParams["error"];

        if (routeError) {
            this.errorMessage.set(routeError);
        } else if (queryError) {
            this.errorMessage.set(queryError);
        }
    }

    /**
     * Go back to previous page
     */
    goBack(): void {
        if (this.canGoBack()) {
            window.history.back();
        } else {
            this.goToLogin();
        }
    }

    /**
     * Go to login page
     */
    goToLogin(): void {
        // Clear session and redirect to login
        this.authService.logout();
        this.router.navigate(["/login"]);
    }
}
