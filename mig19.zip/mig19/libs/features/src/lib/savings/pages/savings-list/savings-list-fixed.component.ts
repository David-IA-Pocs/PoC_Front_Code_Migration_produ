import { Component, inject, signal, computed, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { Router } from "@angular/router";
import { AuthService } from "../../../../../../core/src/lib/auth/auth.service";
import {
    SavingsService,
    SavingsAccount,
} from "../../../../../../data-access/src/lib/savings-api/savings.service";
import { CardComponent } from "../../../../../../shared/src/lib/components/card/card.component";
import { ButtonComponent } from "../../../../../../shared/src/lib/components/button/button.component";

/**
 * Savings List Component
 * Migrated from AngularJS SavingsAccountsController with Angular Signals
 */
@Component({
    selector: "app-savings-list",
    standalone: true,
    imports: [CommonModule, CardComponent, ButtonComponent],
    template: `
        <div class="savings-list-container">
            <app-card variant="elevated" class="savings-card">
                <!-- Header -->
                <div class="page-header">
                    <h1 class="page-title">Mis Cuentas de Ahorros</h1>
                    <p class="page-subtitle">
                        Gestiona y consulta el estado de tus cuentas
                    </p>
                </div>

                <!-- Summary Cards -->
                <div class="summary-section">
                    <div class="summary-grid">
                        <div class="summary-card">
                            <div class="summary-icon total-accounts">
                                <svg viewBox="0 0 24 24">
                                    <path
                                        d="M19,3H5C3.9,3 3,3.9 3,5V19C3,20.1 3.9,21 5,21H19C20.1,21 21,20.1 21,19V5C21,3.9 20.1,3 19,3M19,19H5V5H19V19Z"
                                    />
                                </svg>
                            </div>
                            <div class="summary-content">
                                <h3 class="summary-title">Total de Cuentas</h3>
                                <p class="summary-value">
                                    {{ accounts().length }}
                                </p>
                            </div>
                        </div>

                        <div class="summary-card">
                            <div class="summary-icon active-accounts">
                                <svg viewBox="0 0 24 24">
                                    <path
                                        d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"
                                    />
                                </svg>
                            </div>
                            <div class="summary-content">
                                <h3 class="summary-title">Cuentas Activas</h3>
                                <p class="summary-value">
                                    {{ getActiveAccountsCount() }}
                                </p>
                            </div>
                        </div>

                        <div class="summary-card">
                            <div class="summary-icon total-balance">
                                <svg viewBox="0 0 24 24">
                                    <path
                                        d="M11.8,10.9C9.53,10.31 8.8,9.7 8.8,8.75C8.8,7.66 9.81,6.9 11.5,6.9C13.28,6.9 13.94,7.75 14,9H16.21C16.14,7.28 15.09,5.7 13,5.19V3H10V5.16C8.06,5.58 6.5,6.84 6.5,8.77C6.5,11.08 8.41,12.23 11.2,12.9C13.7,13.5 14.2,14.38 14.2,15.31C14.2,16 13.71,17.1 11.5,17.1C9.44,17.1 8.63,16.18 8.5,15H6.32C6.44,17.19 8.08,18.42 10,18.83V21H13V18.85C14.95,18.5 16.5,17.35 16.5,15.3C16.5,12.46 14.07,11.5 11.8,10.9Z"
                                    />
                                </svg>
                            </div>
                            <div class="summary-content">
                                <h3 class="summary-title">Saldo Total</h3>
                                <p class="summary-value">
                                    \${{ getTotalBalance().toFixed(2) }}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Error Message -->
                @if (error()) {
                    <div class="message message-error">{{ error() }}</div>
                }

                <!-- Loading State -->
                @if (isLoading()) {
                    <div class="loading-section">
                        <div class="loading-spinner-large"></div>
                        <p>Cargando cuentas de ahorros...</p>
                    </div>
                }

                <!-- Accounts List -->
                @if (!isLoading() && accounts().length > 0) {
                    <div class="accounts-section">
                        <div class="section-header">
                            <h3 class="section-title">Listado de Cuentas</h3>
                            <app-button
                                variant="primary"
                                size="medium"
                                (clicked)="navigateToCreateAccount()"
                            >
                                Nueva Cuenta
                            </app-button>
                        </div>

                        <div class="accounts-grid">
                            @for (account of accounts(); track account.id) {
                                <div
                                    class="account-card"
                                    (click)="viewAccountDetails(account)"
                                >
                                    <div class="account-header">
                                        <div class="account-number">
                                            <h4>{{ account.accountNumber }}</h4>
                                            <span
                                                class="account-status"
                                                [class.status-active]="
                                                    account.status === 'Active'
                                                "
                                                [class.status-inactive]="
                                                    account.status !== 'Active'
                                                "
                                            >
                                                {{ account.status }}
                                            </span>
                                        </div>
                                        <div class="account-balance">
                                            <span class="balance-label"
                                                >Saldo</span
                                            >
                                            <span class="balance-amount"
                                                >\${{
                                                    account.initialDeposit.toFixed(
                                                        2
                                                    ) || "0.00"
                                                }}</span
                                            >
                                        </div>
                                    </div>

                                    <div class="account-details">
                                        <div class="detail-row">
                                            <span class="detail-label"
                                                >Titular:</span
                                            >
                                            <span class="detail-value">{{
                                                account.titularName
                                            }}</span>
                                        </div>
                                        <div class="detail-row">
                                            <span class="detail-label"
                                                >Identificación:</span
                                            >
                                            <span class="detail-value"
                                                >{{
                                                    account.identificationType
                                                }}
                                                -
                                                {{
                                                    account.identificationNumber
                                                }}</span
                                            >
                                        </div>
                                        <div class="detail-row">
                                            <span class="detail-label"
                                                >Teléfono:</span
                                            >
                                            <span class="detail-value">{{
                                                account.phoneNumber
                                            }}</span>
                                        </div>
                                        <div class="detail-row">
                                            <span class="detail-label"
                                                >Fecha de Creación:</span
                                            >
                                            <span class="detail-value">{{
                                                formatDate(account.createdDate)
                                            }}</span>
                                        </div>
                                    </div>

                                    <div class="account-actions">
                                        <button
                                            class="btn-details"
                                            (click)="
                                                viewAccountDetails(account);
                                                $event.stopPropagation()
                                            "
                                        >
                                            Ver Detalles
                                        </button>
                                    </div>
                                </div>
                            }
                        </div>
                    </div>
                }

                <!-- Empty State -->
                @if (!isLoading() && accounts().length === 0 && !error()) {
                    <div class="empty-state">
                        <div class="empty-icon">
                            <svg viewBox="0 0 24 24">
                                <path
                                    d="M19,3H5C3.9,3 3,3.9 3,5V19C3,20.1 3.9,21 5,21H19C20.1,21 21,20.1 21,19V5C21,3.9 20.1,3 19,3M19,19H5V5H19V19M17,12V14H7V12H17M15,16V18H9V16H15Z"
                                />
                            </svg>
                        </div>
                        <h3 class="empty-title">
                            No tienes cuentas de ahorros
                        </h3>
                        <p class="empty-description">
                            Crea tu primera cuenta de ahorros para comenzar a
                            gestionar tus finanzas
                        </p>
                        <app-button
                            variant="primary"
                            size="large"
                            (clicked)="navigateToCreateAccount()"
                        >
                            Crear Primera Cuenta
                        </app-button>
                    </div>
                }

                <!-- Actions -->
                @if (!isLoading() && accounts().length > 0) {
                    <div class="page-actions">
                        <app-button
                            variant="outline"
                            (clicked)="refreshAccounts()"
                        >
                            Actualizar
                        </app-button>

                        <app-button
                            variant="secondary"
                            (clicked)="goToUserDashboard()"
                        >
                            Volver al Panel
                        </app-button>
                    </div>
                }
            </app-card>
        </div>
    `,
    styleUrl: "./savings-list.component.scss",
})
export class SavingsListComponent implements OnInit {
    private readonly authService = inject(AuthService);
    private readonly savingsService = inject(SavingsService);
    private readonly router = inject(Router);

    // Component state using signals
    protected readonly accounts = signal<SavingsAccount[]>([]);
    protected readonly isLoading = signal(false);
    protected readonly error = signal<string | null>(null);

    // Computed properties
    protected readonly totalBalance = computed(() =>
        this.accounts().reduce(
            (sum, account) => sum + (account.initialDeposit || 0),
            0
        )
    );

    protected readonly activeAccountsCount = computed(
        () =>
            this.accounts().filter((account) => account.status === "Active")
                .length
    );

    ngOnInit(): void {
        this.loadAccounts();
    }

    /**
     * Load all savings accounts for the current user
     */
    loadAccounts(): void {
        this.isLoading.set(true);
        this.error.set(null);

        this.savingsService.getMyAccounts().subscribe({
            next: (response) => {
                this.isLoading.set(false);
                if (response.accounts) {
                    this.accounts.set(response.accounts);
                } else {
                    this.error.set("Error al cargar las cuentas");
                }
            },
            error: (error) => {
                this.isLoading.set(false);
                this.error.set(
                    error?.data?.message ||
                        "Error de conexión al cargar las cuentas"
                );
                console.error("Error loading accounts:", error);
            },
        });
    }

    /**
     * Navigate to create new account
     */
    navigateToCreateAccount(): void {
        this.router.navigate(["/create-savings"]);
    }

    /**
     * Navigate back to user dashboard
     */
    goToUserDashboard(): void {
        this.router.navigate(["/user"]);
    }

    /**
     * Refresh accounts list
     */
    refreshAccounts(): void {
        this.loadAccounts();
    }

    /**
     * View account details (placeholder)
     */
    viewAccountDetails(account: SavingsAccount): void {
        console.log("View details for account:", account);
        // TODO: Navigate to account details page or show modal
    }

    /**
     * Get total balance
     */
    getTotalBalance(): number {
        return this.totalBalance();
    }

    /**
     * Get count of active accounts
     */
    getActiveAccountsCount(): number {
        return this.activeAccountsCount();
    }

    /**
     * Format date for display
     */
    formatDate(dateString: string): string {
        if (!dateString) return "N/A";

        try {
            const date = new Date(dateString);
            return date.toLocaleDateString("es-ES", {
                year: "numeric",
                month: "short",
                day: "numeric",
            });
        } catch {
            return "Fecha inválida";
        }
    }
}
