import { Component, inject, signal, computed } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { Router } from "@angular/router";
import { AuthService } from "@core/auth/auth.service";
import {
    SavingsService,
    SavingsAccountData,
} from "@data-access/savings-api/savings.service";
import { CardComponent } from "@shared/components/card/card.component";
import { InputComponent } from "@shared/components/input/input.component";
import { ButtonComponent } from "@shared/components/button/button.component";

/**
 * Create Savings Account Component
 * Migrated from AngularJS CreateSavingsController with Angular Signals
 */
@Component({
    selector: "app-create-savings",
    standalone: true,
    imports: [
        CommonModule,
        FormsModule,
        CardComponent,
        InputComponent,
        ButtonComponent,
    ],
    template: `
        <div class="create-savings-container">
            <app-card variant="elevated" class="savings-card">
                <!-- Progress Header -->
                <div class="progress-header">
                    <h1 class="page-title">Crear Cuenta de Ahorros</h1>
                    <div class="progress-bar">
                        <div class="progress-steps">
                            @for (
                                step of [1, 2, 3];
                                track step;
                                let i = $index
                            ) {
                                <div
                                    class="progress-step"
                                    [class.active]="currentStep() === step"
                                    [class.completed]="currentStep() > step"
                                >
                                    <span class="step-number">{{ step }}</span>
                                    <span class="step-title">{{
                                        getStepTitle(step)
                                    }}</span>
                                </div>
                            }
                        </div>
                        <div class="progress-line">
                            <div
                                class="progress-fill"
                                [style.width.%]="progressPercentage()"
                            ></div>
                        </div>
                    </div>
                    <p class="step-description">
                        {{ getStepDescription(currentStep()) }}
                    </p>
                </div>

                <!-- Error/Success Messages -->
                @if (error()) {
                    <div class="message message-error">{{ error() }}</div>
                }

                @if (success()) {
                    <div class="message message-success">{{ success() }}</div>
                }

                <!-- Form Steps -->
                <form (ngSubmit)="submitForm()" #savingsForm="ngForm">
                    <!-- Step 1: Personal Information -->
                    @if (currentStep() === 1) {
                        <div class="form-step">
                            <div class="form-grid form-grid-2">
                                <app-input
                                    inputId="titularName"
                                    type="text"
                                    label="Nombre del Titular"
                                    placeholder="Ingrese el nombre completo"
                                    [value]="formData().titularName"
                                    [required]="true"
                                    [minLength]="2"
                                    (valueChange)="
                                        updateFormData('titularName', $event)
                                    "
                                />

                                <app-input
                                    inputId="identificationType"
                                    type="text"
                                    label="Tipo de Identificación"
                                    placeholder="Seleccione tipo"
                                    [value]="formData().identificationType"
                                    [required]="true"
                                    (valueChange)="
                                        updateFormData(
                                            'identificationType',
                                            $event
                                        )
                                    "
                                />
                            </div>

                            <app-input
                                inputId="identificationNumber"
                                type="text"
                                label="Número de Identificación"
                                placeholder="Ingrese el número de identificación"
                                [value]="formData().identificationNumber"
                                [required]="true"
                                [minLength]="5"
                                (valueChange)="
                                    updateFormData(
                                        'identificationNumber',
                                        $event
                                    )
                                "
                            />

                            <!-- ID Type Selection -->
                            <div class="id-type-selection">
                                <label class="form-label"
                                    >Tipo de Identificación</label
                                >
                                <div class="radio-group">
                                    @for (
                                        idType of identificationTypes;
                                        track idType.value
                                    ) {
                                        <label class="radio-option">
                                            <input
                                                type="radio"
                                                [value]="idType.value"
                                                [checked]="
                                                    formData()
                                                        .identificationType ===
                                                    idType.value
                                                "
                                                (change)="
                                                    updateFormData(
                                                        'identificationType',
                                                        idType.value
                                                    )
                                                "
                                            />
                                            <span class="radio-label">{{
                                                idType.label
                                            }}</span>
                                        </label>
                                    }
                                </div>
                            </div>
                        </div>
                    }

                    <!-- Step 2: Contact Information -->
                    @if (currentStep() === 2) {
                        <div class="form-step">
                            <app-input
                                inputId="phoneNumber"
                                type="tel"
                                label="Número de Teléfono"
                                placeholder="Ingrese su número de teléfono"
                                [value]="formData().phoneNumber"
                                [required]="true"
                                [minLength]="7"
                                (valueChange)="
                                    updateFormData('phoneNumber', $event)
                                "
                            />

                            <app-input
                                inputId="address"
                                type="text"
                                label="Dirección"
                                placeholder="Ingrese su dirección completa"
                                [value]="formData().address"
                                [required]="true"
                                [minLength]="10"
                                (valueChange)="
                                    updateFormData('address', $event)
                                "
                            />
                        </div>
                    }

                    <!-- Step 3: Initial Deposit -->
                    @if (currentStep() === 3) {
                        <div class="form-step">
                            <app-input
                                inputId="initialDeposit"
                                type="number"
                                label="Depósito Inicial"
                                placeholder="Ingrese el monto del depósito inicial"
                                [value]="
                                    formData().initialDeposit.toString() || ''
                                "
                                [required]="true"
                                [min]="50"
                                (valueChange)="
                                    updateFormData('initialDeposit', +$event)
                                "
                            />

                            <div class="deposit-info">
                                <h4>Información del Depósito</h4>
                                <ul>
                                    <li>El depósito mínimo es de $50.00</li>
                                    <li>
                                        Este monto estará disponible
                                        inmediatamente
                                    </li>
                                    <li>
                                        No hay comisiones por apertura de cuenta
                                    </li>
                                    <li>
                                        La cuenta generará intereses desde el
                                        primer día
                                    </li>
                                </ul>
                            </div>

                            <!-- Form Summary -->
                            <div class="form-summary">
                                <h4>Resumen de la Cuenta</h4>
                                <div class="summary-grid">
                                    <div class="summary-row">
                                        <span>Titular:</span>
                                        <strong>{{
                                            formData().titularName
                                        }}</strong>
                                    </div>
                                    <div class="summary-row">
                                        <span>Identificación:</span>
                                        <strong
                                            >{{
                                                getIdTypeLabel(
                                                    formData()
                                                        .identificationType
                                                )
                                            }}
                                            -
                                            {{
                                                formData().identificationNumber
                                            }}</strong
                                        >
                                    </div>
                                    <div class="summary-row">
                                        <span>Teléfono:</span>
                                        <strong>{{
                                            formData().phoneNumber
                                        }}</strong>
                                    </div>
                                    <div class="summary-row">
                                        <span>Depósito Inicial:</span>
                                        <strong
                                            >\${{
                                                formData().initialDeposit.toFixed(
                                                    2
                                                ) || "0.00"
                                            }}</strong
                                        >
                                    </div>
                                </div>
                            </div>
                        </div>
                    }

                    <!-- Success Step -->
                    @if (currentStep() === 4 && createdAccount()) {
                        <div class="success-step">
                            <div class="success-icon">
                                <svg viewBox="0 0 24 24">
                                    <path
                                        d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"
                                    />
                                </svg>
                            </div>

                            <h2 class="success-title">
                                ¡Cuenta Creada Exitosamente!
                            </h2>

                            <div class="account-details">
                                <h4>Detalles de tu Nueva Cuenta</h4>
                                <div class="detail-grid">
                                    <div class="detail-row">
                                        <span>Número de Cuenta:</span>
                                        <strong>{{
                                            createdAccount()?.accountNumber
                                        }}</strong>
                                    </div>
                                    <div class="detail-row">
                                        <span>Titular:</span>
                                        <strong>{{
                                            createdAccount()?.titularName
                                        }}</strong>
                                    </div>
                                    <div class="detail-row">
                                        <span>Saldo Inicial:</span>
                                        <strong
                                            >\${{
                                                createdAccount()?.initialDeposit?.toFixed(
                                                    2
                                                )
                                            }}</strong
                                        >
                                    </div>
                                    <div class="detail-row">
                                        <span>Estado:</span>
                                        <strong class="status-active">{{
                                            createdAccount()?.status
                                        }}</strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    }

                    <!-- Form Actions -->
                    @if (currentStep() < 4) {
                        <div class="form-actions">
                            @if (currentStep() > 1) {
                                <app-button
                                    type="button"
                                    variant="outline"
                                    (clicked)="prevStep()"
                                >
                                    Anterior
                                </app-button>
                            }

                            @if (currentStep() < 3) {
                                <app-button
                                    type="button"
                                    variant="primary"
                                    [disabled]="!isStepValid(currentStep())"
                                    (clicked)="nextStep()"
                                >
                                    Siguiente
                                </app-button>
                            } @else {
                                <app-button
                                    type="submit"
                                    variant="primary"
                                    [loading]="isLoading()"
                                    [disabled]="!isStepValid(currentStep())"
                                >
                                    Crear Cuenta
                                </app-button>
                            }
                        </div>
                    } @else {
                        <div class="success-actions">
                            <app-button
                                variant="outline"
                                (clicked)="createAnotherAccount()"
                            >
                                Crear Otra Cuenta
                            </app-button>

                            <app-button
                                variant="primary"
                                (clicked)="goToUserDashboard()"
                            >
                                Ir al Panel Principal
                            </app-button>
                        </div>
                    }
                </form>

                @if (isLoading()) {
                    <div class="loading-overlay">
                        <div class="loading-spinner-large"></div>
                    </div>
                }
            </app-card>
        </div>
    `,
    styles: [
        `
            .create-savings-container {
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: var(--spacing-xl);
            }

            .savings-card {
                max-width: 800px;
                width: 100%;
                position: relative;
            }

            .progress-header {
                text-align: center;
                margin-bottom: var(--spacing-xl);
                padding-bottom: var(--spacing-xl);
                border-bottom: 1px solid var(--border-light);
            }

            .page-title {
                font-size: var(--font-size-3xl);
                font-weight: var(--font-weight-bold);
                color: var(--text-primary);
                margin-bottom: var(--spacing-lg);
            }

            .progress-bar {
                position: relative;
                margin-bottom: var(--spacing-lg);
            }

            .progress-steps {
                display: flex;
                justify-content: space-between;
                position: relative;
                z-index: 2;
            }

            .progress-step {
                display: flex;
                flex-direction: column;
                align-items: center;
                text-align: center;
            }

            .step-number {
                display: flex;
                align-items: center;
                justify-content: center;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                background: var(--background-secondary);
                border: 2px solid var(--border-medium);
                color: var(--text-secondary);
                font-weight: var(--font-weight-semibold);
                transition: all var(--transition-normal);
            }

            .progress-step.active .step-number {
                background: var(--primary-color);
                border-color: var(--primary-color);
                color: var(--text-on-primary);
            }

            .progress-step.completed .step-number {
                background: var(--color-success);
                border-color: var(--color-success);
                color: var(--text-on-primary);
            }

            .step-title {
                font-size: var(--font-size-sm);
                color: var(--text-secondary);
                margin-top: var(--spacing-sm);
                font-weight: var(--font-weight-medium);
            }

            .progress-step.active .step-title {
                color: var(--primary-color);
            }

            .progress-line {
                position: absolute;
                top: 20px;
                left: 20px;
                right: 20px;
                height: 2px;
                background: var(--border-medium);
                z-index: 1;
            }

            .progress-fill {
                height: 100%;
                background: var(--primary-color);
                transition: width var(--transition-normal);
            }

            .step-description {
                color: var(--text-secondary);
                font-size: var(--font-size-base);
                margin: 0;
            }

            .form-step {
                margin-bottom: var(--spacing-xl);
            }

            .id-type-selection {
                margin-bottom: var(--spacing-lg);
            }

            .radio-group {
                display: flex;
                gap: var(--spacing-lg);
                flex-wrap: wrap;
            }

            .radio-option {
                display: flex;
                align-items: center;
                gap: var(--spacing-sm);
                cursor: pointer;
            }

            .radio-option input[type="radio"] {
                margin: 0;
            }

            .radio-label {
                color: var(--text-primary);
                font-size: var(--font-size-sm);
            }

            .deposit-info {
                background: var(--primary-color-light);
                border: 1px solid rgba(0, 176, 79, 0.2);
                border-radius: var(--border-radius-medium);
                padding: var(--spacing-lg);
                margin-bottom: var(--spacing-lg);
            }

            .deposit-info h4 {
                color: var(--text-primary);
                margin-bottom: var(--spacing-md);
                font-size: var(--font-size-lg);
            }

            .deposit-info ul {
                margin: 0;
                padding-left: var(--spacing-lg);
                color: var(--text-secondary);
            }

            .deposit-info li {
                margin-bottom: var(--spacing-sm);
                line-height: var(--line-height-relaxed);
            }

            .form-summary,
            .account-details {
                background: var(--background-secondary);
                border: 1px solid var(--border-light);
                border-radius: var(--border-radius-medium);
                padding: var(--spacing-lg);
                margin-bottom: var(--spacing-lg);
            }

            .form-summary h4,
            .account-details h4 {
                color: var(--text-primary);
                margin-bottom: var(--spacing-md);
                font-size: var(--font-size-lg);
            }

            .summary-grid,
            .detail-grid {
                display: grid;
                gap: var(--spacing-md);
            }

            .summary-row,
            .detail-row {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: var(--spacing-sm) 0;
                border-bottom: 1px solid var(--border-light);
            }

            .summary-row:last-child,
            .detail-row:last-child {
                border-bottom: none;
            }

            .success-step {
                text-align: center;
                margin-bottom: var(--spacing-xl);
            }

            .success-icon {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 80px;
                height: 80px;
                background: var(--color-success);
                border-radius: 50%;
                margin-bottom: var(--spacing-lg);
            }

            .success-icon svg {
                width: 40px;
                height: 40px;
                fill: var(--text-on-primary);
            }

            .success-title {
                font-size: var(--font-size-2xl);
                font-weight: var(--font-weight-bold);
                color: var(--color-success);
                margin-bottom: var(--spacing-lg);
            }

            .form-actions,
            .success-actions {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: var(--spacing-lg);
                margin-top: var(--spacing-xl);
            }

            /* Responsive design */
            @media (max-width: 768px) {
                .create-savings-container {
                    padding: var(--spacing-lg);
                }

                .page-title {
                    font-size: var(--font-size-2xl);
                }

                .radio-group {
                    flex-direction: column;
                    gap: var(--spacing-md);
                }

                .form-actions,
                .success-actions {
                    flex-direction: column;
                    align-items: stretch;
                }

                .form-actions app-button,
                .success-actions app-button {
                    width: 100%;
                }
            }
        `,
    ],
})
export class CreateSavingsComponent {
    private readonly authService = inject(AuthService);
    private readonly savingsService = inject(SavingsService);
    private readonly router = inject(Router);

    // Component state using signals
    protected readonly currentStep = signal(1);
    protected readonly totalSteps = 3;
    protected readonly isLoading = signal(false);
    protected readonly error = signal<string | null>(null);
    protected readonly success = signal<string | null>(null);
    protected readonly createdAccount = signal<any | null>(null);

    // Form data signal
    protected readonly formData = signal<SavingsAccountData>({
        titularName: "",
        identificationNumber: "",
        identificationType: "",
        phoneNumber: "",
        address: "",
        initialDeposit: 0,
    });

    // Identification types
    protected readonly identificationTypes = [
        { value: "cedula", label: "Cédula" },
        { value: "pasaporte", label: "Pasaporte" },
        { value: "ruc", label: "RUC" },
    ];

    // Computed signals
    protected readonly progressPercentage = computed(
        () => ((this.currentStep() - 1) / (this.totalSteps - 1)) * 100
    );

    constructor() {
        // Verify authentication
        if (!this.authService.isAuthenticated()) {
            this.router.navigate(["/login"]);
        }
    }

    /**
     * Update form data
     */
    updateFormData(field: keyof SavingsAccountData, value: any): void {
        this.formData.update((data) => ({ ...data, [field]: value }));
        this.clearMessages();
    }

    /**
     * Go to next step
     */
    nextStep(): void {
        if (
            this.currentStep() < this.totalSteps &&
            this.isStepValid(this.currentStep())
        ) {
            this.currentStep.update((step) => step + 1);
            this.clearMessages();
        }
    }

    /**
     * Go to previous step
     */
    prevStep(): void {
        if (this.currentStep() > 1) {
            this.currentStep.update((step) => step - 1);
            this.clearMessages();
        }
    }

    /**
     * Submit form to create account
     */
    submitForm(): void {
        if (!this.isStepValid(3)) {
            return;
        }

        this.clearMessages();
        this.isLoading.set(true);

        this.savingsService.createSavingsAccount(this.formData()).subscribe({
            next: (response) => {
                this.isLoading.set(false);
                this.createdAccount.set(response.account);
                this.success.set(
                    response.message || "Cuenta de ahorros creada exitosamente"
                );
                this.currentStep.set(4);
            },
            error: (error) => {
                this.isLoading.set(false);
                this.error.set(
                    error.data?.message || "Error al crear la cuenta de ahorros"
                );
                console.error("Error creating savings account:", error);
            },
        });
    }

    /**
     * Check if current step is valid
     */
    isStepValid(step: number): boolean {
        const data = this.formData();

        switch (step) {
            case 1:
                return !!(
                    data.titularName?.length >= 2 &&
                    data.identificationNumber?.length >= 5 &&
                    data.identificationType
                );
            case 2:
                return !!(
                    data.phoneNumber?.length >= 7 && data.address?.length >= 10
                );
            case 3:
                return !!(data.initialDeposit && data.initialDeposit >= 50);
            default:
                return false;
        }
    }

    /**
     * Get step title
     */
    getStepTitle(step: number): string {
        switch (step) {
            case 1:
                return "Información Personal";
            case 2:
                return "Datos de Contacto";
            case 3:
                return "Depósito Inicial";
            default:
                return "Cuenta Creada";
        }
    }

    /**
     * Get step description
     */
    getStepDescription(step: number): string {
        switch (step) {
            case 1:
                return "Ingrese los datos personales del titular de la cuenta";
            case 2:
                return "Proporcione la información de contacto";
            case 3:
                return "Defina el monto del depósito inicial";
            default:
                return "Su cuenta ha sido creada exitosamente";
        }
    }

    /**
     * Get identification type label
     */
    getIdTypeLabel(value: string): string {
        const type = this.identificationTypes.find((t) => t.value === value);
        return type?.label || value;
    }

    /**
     * Go to user dashboard
     */
    goToUserDashboard(): void {
        this.router.navigate(["/user"]);
    }

    /**
     * Create another account
     */
    createAnotherAccount(): void {
        // Reset form
        this.currentStep.set(1);
        this.formData.set({
            titularName: "",
            identificationNumber: "",
            identificationType: "",
            phoneNumber: "",
            address: "",
            initialDeposit: 0,
        });
        this.clearMessages();
        this.createdAccount.set(null);
    }

    /**
     * Clear error and success messages
     */
    private clearMessages(): void {
        this.error.set(null);
        this.success.set(null);
    }
}
