import { Component, inject, signal, computed, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { AuthService } from "@core/auth/auth.service";
import { BackendService } from "@data-access/backend-api/backend.service";
import { CardComponent } from "@shared/components/card/card.component";
import { ButtonComponent } from "@shared/components/button/button.component";

/**
 * Admin Dashboard Component
 * Migrated from AngularJS AdminController with Angular Signals
 */
@Component({
    selector: "app-admin-dashboard",
    standalone: true,
    imports: [CommonModule, CardComponent, ButtonComponent],
    template: `
        <app-card variant="elevated" class="dashboard-card">
            <!-- Header -->
            <div class="dashboard-header">
                <div class="admin-avatar">
                    <svg viewBox="0 0 24 24">
                        <path
                            d="M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1M12,7C13.1,7 14,7.9 14,9C14,10.1 13.1,11 12,11C10.9,11 10,10.1 10,9C10,7.9 10.9,7 12,7M12,13C13.1,13 14,13.9 14,15C14,16.1 13.1,17 12,17C10.9,17 10,16.1 10,15C10,13.9 10.9,13 12,13Z"
                        />
                    </svg>
                </div>
                <h1 class="welcome-title">{{ welcomeMessage() }}</h1>
                <p class="dashboard-subtitle">
                    Panel de Administrador - Produbanco
                </p>
            </div>

            <!-- Admin Information -->
            <div class="info-section">
                <h3 class="section-title">Información del Administrador</h3>
                @if (userInfo(); as user) {
                    <div class="info-grid">
                        <div class="info-row">
                            <span class="info-label">Usuario:</span>
                            <span class="info-value">{{ user.username }}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Email:</span>
                            <span class="info-value">{{ user.email }}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Rol:</span>
                            <span class="info-value">Administrador</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Estado:</span>
                            <span class="status-active">
                                <span class="status-indicator"></span>
                                Activo
                            </span>
                        </div>
                    </div>
                }
            </div>

            <!-- System Status -->
            <div class="status-section">
                <h3 class="section-title">Estado del Sistema</h3>
                <div class="status-grid">
                    <div class="status-card">
                        <div class="status-icon status-icon-backend">
                            <svg viewBox="0 0 24 24">
                                <path
                                    d="M4,6H20V16H4M20,18A2,2 0 0,0 22,16V6C22,4.89 21.1,4 20,4H4C2.89,4 2,4.89 2,6V16A2,2 0 0,0 4,18H0V20H24V18H20Z"
                                />
                            </svg>
                        </div>
                        <h4 class="status-title">Estado del Backend</h4>
                        <p class="status-value">
                            {{ healthStatus() || "Verificando..." }}
                        </p>
                        <app-button
                            variant="outline"
                            size="small"
                            (clicked)="checkBackendHealth()"
                        >
                            Verificar
                        </app-button>
                    </div>
                </div>
            </div>

            <!-- Admin Actions -->
            <div class="actions-section">
                <h3 class="section-title">Acciones de Administrador</h3>

                <div class="actions-grid">
                    <!-- Test Admin Access -->
                    <div class="action-card">
                        <div class="action-icon">
                            <svg viewBox="0 0 24 24">
                                <path
                                    d="M9,11H15V13H9V11M9,7H15V9H9V7M9,15H15V17H9V15M7,5V19H17V5H7M17,3A2,2 0 0,1 19,5V19A2,2 0 0,1 17,21H7A2,2 0 0,1 5,19V5A2,2 0 0,1 7,3H17Z"
                                />
                            </svg>
                        </div>
                        <h4 class="action-title">Probar Acceso Admin</h4>
                        <p class="action-description">
                            Verificar permisos de administrador en el sistema
                        </p>
                        <app-button
                            variant="primary"
                            size="medium"
                            [loading]="isTestingAccess()"
                            (clicked)="testAdminAccess()"
                        >
                            Probar Acceso
                        </app-button>
                    </div>

                    <!-- System Monitoring -->
                    <div class="action-card">
                        <div class="action-icon">
                            <svg viewBox="0 0 24 24">
                                <path
                                    d="M3,3H21V19H19V5H5V17H15V19H3V3M20,10V21H12V19H18V12H16V10H20Z"
                                />
                            </svg>
                        </div>
                        <h4 class="action-title">Monitoreo</h4>
                        <p class="action-description">
                            Supervisar el estado y rendimiento del sistema
                        </p>
                        <app-button
                            variant="secondary"
                            size="medium"
                            [disabled]="true"
                        >
                            Próximamente
                        </app-button>
                    </div>

                    <!-- User Management -->
                    <div class="action-card">
                        <div class="action-icon">
                            <svg viewBox="0 0 24 24">
                                <path
                                    d="M16,4C16.88,4 17.67,4.38 18.18,5L20,6.8L18.18,8.62C17.67,9.25 16.88,9.62 16,9.62C14.71,9.62 13.67,8.59 13.67,7.3C13.67,6 14.71,4.97 16,4.97M16,2C13.61,2 11.67,3.94 11.67,6.33C11.67,8.72 13.61,10.66 16,10.66C18.39,10.66 20.33,8.72 20.33,6.33C20.33,3.94 18.39,2 16,2M9,12C10.1,12 11,11.1 11,10S10.1,8 9,8 7,8.9 7,10 7.9,12 9,12M9,6A4,4 0 0,1 13,10A4,4 0 0,1 9,14A4,4 0 0,1 5,10A4,4 0 0,1 9,6M9,16C11.67,16 17,17.33 17,20V22H1V20C1,17.33 6.33,16 9,16Z"
                                />
                            </svg>
                        </div>
                        <h4 class="action-title">Gestión de Usuarios</h4>
                        <p class="action-description">
                            Administrar usuarios y permisos del sistema
                        </p>
                        <app-button
                            variant="secondary"
                            size="medium"
                            [disabled]="true"
                        >
                            Próximamente
                        </app-button>
                    </div>
                </div>
            </div>

            <!-- Test Results -->
            @if (testMessage()) {
                <div class="test-section">
                    <h3 class="section-title">Resultado de Prueba</h3>
                    <div
                        class="message"
                        [class.message-success]="
                            !testMessage().includes('Error')
                        "
                        [class.message-error]="testMessage().includes('Error')"
                    >
                        {{ testMessage() }}
                    </div>
                </div>
            }

            @if (isTestingAccess() || isCheckingHealth()) {
                <div class="loading-overlay">
                    <div class="loading-spinner-large"></div>
                </div>
            }
        </app-card>
    `,
    styles: [
        `
            .dashboard-card {
                max-width: 1000px;
                margin: 0 auto;
                position: relative;
            }

            .dashboard-header {
                text-align: center;
                margin-bottom: var(--spacing-xl);
                padding-bottom: var(--spacing-xl);
                border-bottom: 1px solid var(--border-light);
            }

            .admin-avatar {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 80px;
                height: 80px;
                background: var(--secondary-color);
                border-radius: 50%;
                margin-bottom: var(--spacing-lg);
            }

            .admin-avatar svg {
                width: 40px;
                height: 40px;
                fill: var(--text-on-primary);
            }

            .welcome-title {
                color: var(--text-primary);
                font-size: var(--font-size-2xl);
                font-weight: var(--font-weight-semibold);
                margin: 0 0 var(--spacing-sm) 0;
            }

            .dashboard-subtitle {
                color: var(--text-secondary);
                font-size: var(--font-size-base);
                margin: 0;
            }

            .info-section,
            .status-section,
            .actions-section,
            .test-section {
                margin-bottom: var(--spacing-xl);
            }

            .section-title {
                color: var(--text-primary);
                margin-bottom: var(--spacing-lg);
                font-size: var(--font-size-lg);
                font-weight: var(--font-weight-semibold);
            }

            .info-grid {
                background: var(--background-secondary);
                border: 1px solid var(--border-light);
                border-radius: var(--border-radius-medium);
                padding: var(--spacing-xl);
            }

            .status-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: var(--spacing-lg);
            }

            .status-card {
                background: var(--surface-primary);
                border: 1px solid var(--border-light);
                border-radius: var(--border-radius-medium);
                padding: var(--spacing-lg);
                text-align: center;
            }

            .status-icon {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 48px;
                height: 48px;
                border-radius: var(--border-radius-medium);
                margin-bottom: var(--spacing-md);
            }

            .status-icon-backend {
                background: var(--secondary-color);
            }

            .status-icon svg {
                width: 24px;
                height: 24px;
                fill: var(--text-on-primary);
            }

            .status-title {
                font-size: var(--font-size-lg);
                font-weight: var(--font-weight-semibold);
                color: var(--text-primary);
                margin-bottom: var(--spacing-sm);
            }

            .status-value {
                font-size: var(--font-size-sm);
                color: var(--text-secondary);
                margin-bottom: var(--spacing-md);
            }

            .actions-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
                gap: var(--spacing-lg);
            }

            .action-card {
                background: var(--surface-primary);
                border: 1px solid var(--border-light);
                border-radius: var(--border-radius-medium);
                padding: var(--spacing-lg);
                text-align: center;
                transition: all var(--transition-normal);
            }

            .action-card:hover {
                box-shadow: var(--shadow-medium);
                transform: translateY(-2px);
            }

            .action-icon {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 48px;
                height: 48px;
                background: var(--primary-color);
                border-radius: var(--border-radius-medium);
                margin-bottom: var(--spacing-lg);
            }

            .action-icon svg {
                width: 24px;
                height: 24px;
                fill: var(--text-on-primary);
            }

            .action-title {
                font-size: var(--font-size-lg);
                font-weight: var(--font-weight-semibold);
                color: var(--text-primary);
                margin-bottom: var(--spacing-sm);
            }

            .action-description {
                font-size: var(--font-size-sm);
                color: var(--text-secondary);
                line-height: var(--line-height-relaxed);
                margin-bottom: var(--spacing-lg);
            }

            /* Responsive design */
            @media (max-width: 768px) {
                .status-grid,
                .actions-grid {
                    grid-template-columns: 1fr;
                }
            }
        `,
    ],
})
export class AdminDashboardComponent implements OnInit {
    private readonly authService = inject(AuthService);
    private readonly backendService = inject(BackendService);

    // Component state using signals
    protected readonly testMessage = signal("");
    protected readonly isTestingAccess = signal(false);
    protected readonly healthStatus = signal("");
    protected readonly isCheckingHealth = signal(false);

    // Computed signals
    protected readonly userInfo = computed(() => this.authService.userInfo());
    protected readonly welcomeMessage = computed(() => {
        const user = this.userInfo();
        return user?.username
            ? `Bienvenido, administrador ${user.username}`
            : "Bienvenido, administrador";
    });

    ngOnInit(): void {
        // Component is protected by auth and role guards
        console.log("Admin dashboard loaded for:", this.userInfo());

        // Check backend health automatically
        this.checkBackendHealth();
    }

    /**
     * Test admin access to backend
     */
    testAdminAccess(): void {
        this.isTestingAccess.set(true);
        this.testMessage.set("");

        this.backendService.testAdminAccess().subscribe({
            next: (response) => {
                this.isTestingAccess.set(false);
                this.testMessage.set(
                    response.message || "Acceso de administrador confirmado"
                );
            },
            error: (error) => {
                this.isTestingAccess.set(false);
                this.testMessage.set(
                    `Error al probar acceso: ${error.data?.message || "Error de conexión"}`
                );
            },
        });
    }

    /**
     * Check backend health status
     */
    checkBackendHealth(): void {
        this.isCheckingHealth.set(true);

        this.backendService.checkHealth().subscribe({
            next: (response) => {
                this.isCheckingHealth.set(false);
                this.healthStatus.set(
                    `${response.status} - ${new Date(response.timestamp).toLocaleString()}`
                );
            },
            error: (error) => {
                this.isCheckingHealth.set(false);
                this.healthStatus.set("Error de conexión con el backend");
            },
        });
    }
}
