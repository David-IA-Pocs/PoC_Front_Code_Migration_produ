import { Component, inject, signal, computed, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { Router } from "@angular/router";
import { AuthService } from "../../../../../../core/src/lib/auth/auth.service";
import { BackendService } from "../../../../../../data-access/src/lib/backend-api/backend.service";
import { CardComponent } from "../../../../../../shared/src/lib/components/card/card.component";

/**
 * User Dashboard Component
 * Migrated from AngularJS UserController with Angular Signals
 */
@Component({
    selector: "app-user-dashboard",
    standalone: true,
    imports: [CommonModule, CardComponent],
    template: `
        <app-card variant="elevated" class="dashboard-card">
            <!-- Header -->
            <div class="dashboard-header">
                <div class="user-avatar">
                    <svg viewBox="0 0 24 24">
                        <path
                            d="M12,4A4,4 0 0,1 16,8A4,4 0 0,1 12,12A4,4 0 0,1 8,8A4,4 0 0,1 12,4M12,14C16.42,14 20,15.79 20,18V20H4V18C4,15.79 7.58,14 12,14Z"
                        />
                    </svg>
                </div>
                <h1 class="welcome-title">{{ welcomeMessage() }}</h1>
                <p class="dashboard-subtitle">
                    Panel de Usuario - Produbanco en línea
                </p>
            </div>

            <!-- User Information -->
            <div class="info-section">
                <h3 class="section-title">Información de la Sesión</h3>
                @if (userInfo(); as user) {
                    <div class="info-grid">
                        <div class="info-row">
                            <span class="info-label">Usuario:</span>
                            <span class="info-value">{{ user.username }}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Email:</span>
                            <span class="info-value">{{ user.email }}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Rol:</span>
                            <span class="info-value">Usuario</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Estado:</span>
                            <span class="status-active">
                                <span class="status-indicator"></span>
                                Activo
                            </span>
                        </div>
                    </div>
                }
            </div>

            <!-- Banking Services -->
            <div class="services-section">
                <h3 class="section-title">Servicios Bancarios</h3>

                <div class="services-grid">
                    <!-- Create Savings Account -->
                    <div
                        class="service-card"
                        (click)="navigateToCreateSavings()"
                    >
                        <div class="service-icon">
                            <svg viewBox="0 0 24 24">
                                <path
                                    d="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z"
                                />
                            </svg>
                        </div>
                        <h4 class="service-title">Crear Cuenta de Ahorros</h4>
                        <p class="service-description">
                            Abre una nueva cuenta de ahorros de forma rápida y
                            sencilla
                        </p>
                    </div>

                    <!-- View Savings Accounts -->
                    <div
                        class="service-card"
                        (click)="navigateToSavingsAccounts()"
                    >
                        <div class="service-icon">
                            <svg viewBox="0 0 24 24">
                                <path
                                    d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"
                                />
                            </svg>
                        </div>
                        <h4 class="service-title">Ver Cuentas de Ahorros</h4>
                        <p class="service-description">
                            Consulta el estado y movimientos de tus cuentas
                        </p>
                    </div>

                    <!-- Test Backend Connection -->
                    <div class="service-card" (click)="testUserAccess()">
                        <div class="service-icon">
                            <svg viewBox="0 0 24 24">
                                <path
                                    d="M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4M11,16.5L6.5,12L7.91,10.59L11,13.67L16.59,8.09L18,9.5L11,16.5Z"
                                />
                            </svg>
                        </div>
                        <h4 class="service-title">Probar Conexión</h4>
                        <p class="service-description">
                            Verificar estado de conexión con el servidor
                        </p>
                    </div>
                </div>
            </div>

            <!-- Test Results -->
            @if (testMessage()) {
                <div class="test-section">
                    <h3 class="section-title">Resultado de Prueba</h3>
                    <div
                        class="message"
                        [class.message-success]="
                            !testMessage().includes('Error')
                        "
                        [class.message-error]="testMessage().includes('Error')"
                    >
                        {{ testMessage() }}
                    </div>
                </div>
            }

            @if (isTestingAccess()) {
                <div class="loading-overlay">
                    <div class="loading-spinner-large"></div>
                </div>
            }
        </app-card>
    `,
    styleUrl: "./user-dashboard.component.scss",
})
export class UserDashboardComponent implements OnInit {
    private readonly authService = inject(AuthService);
    private readonly backendService = inject(BackendService);
    private readonly router = inject(Router);

    // Component state using signals
    protected readonly testMessage = signal("");
    protected readonly isTestingAccess = signal(false);

    // Computed signals
    protected readonly userInfo = computed(() => this.authService.userInfo());
    protected readonly welcomeMessage = computed(() => {
        const user = this.userInfo();
        return user?.username
            ? `Bienvenido, ${user.username}`
            : "Bienvenido, usuario";
    });

    ngOnInit(): void {
        // Component is protected by auth guard, so user is authenticated
        console.log("User dashboard loaded for:", this.userInfo());
    }

    /**
     * Navigate to create savings account
     */
    navigateToCreateSavings(): void {
        this.router.navigate(["/create-savings"]);
    }

    /**
     * Navigate to savings accounts list
     */
    navigateToSavingsAccounts(): void {
        this.router.navigate(["/savings-accounts"]);
    }

    /**
     * Test user access to backend
     */
    testUserAccess(): void {
        this.isTestingAccess.set(true);
        this.testMessage.set("");

        this.backendService.testUserAccess().subscribe({
            next: (response) => {
                this.isTestingAccess.set(false);
                this.testMessage.set(
                    response.message || "Acceso de usuario confirmado"
                );
            },
            error: (error) => {
                this.isTestingAccess.set(false);
                this.testMessage.set(
                    `Error al probar acceso: ${error.data?.message || "Error de conexión"}`
                );
            },
        });
    }
}
