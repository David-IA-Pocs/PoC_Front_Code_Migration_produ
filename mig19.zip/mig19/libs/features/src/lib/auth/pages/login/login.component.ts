import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService, LoginCredentials } from '../../../../../../core/src/lib/auth/auth.service';

/**
 * Login Component - 100% identical to AngularJS original
 * Two-step login process: username first, then password
 */
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="login-container">
      <!-- Lado izquierdo - Formulario -->
      <div class="login-left">
        <div class="login-card">
          <!-- Header con logo -->
          <div class="login-header">
            <div class="produbanco-logo">
              <!-- Logo real de Produbanco -->
              <img src="assets/image.png" alt="Produbanco" style="width: 140px; height: auto; max-height: 50px;">
            </div>
            <h1 class="login-title">Hola, te damos la bienvenida</h1>
            <p class="login-subtitle">Ingresa a tu Produbanco en línea</p>
          </div>

          <!-- Cuerpo del formulario -->
          <div class="login-body">
            <!-- Mensaje de error -->
            @if (errorMessage()) {
              <div class="message message-error">
                {{errorMessage()}}
              </div>
            }

            <!-- Formulario completo (siempre presente, pero con partes ocultas) -->
            <form #loginForm="ngForm" (ngSubmit)="login()" novalidate>
              <!-- Paso 1: Usuario -->
              @if (currentStep() === 'username') {
                <!-- Campo Usuario -->
                <div class="form-group" [class.has-error]="usernameField.invalid && usernameField.touched">
                  <label for="username" class="form-label">Usuario</label>
                  <input 
                    type="text" 
                    id="username"
                    name="username"
                    #usernameField="ngModel"
                    class="form-control"
                    [(ngModel)]="credentials.username"
                    (focus)="clearError()"
                    placeholder="Ingresa tu nombre de usuario"
                    required
                    minlength="3">
                  @if (usernameField.invalid && usernameField.touched) {
                    <span class="error-text">
                      @if (usernameField.errors?.['required']) {
                        <span>El usuario es requerido</span>
                      }
                      @if (usernameField.errors?.['minlength']) {
                        <span>El usuario debe tener al menos 3 caracteres</span>
                      }
                    </span>
                  }
                </div>

                <!-- Botón de continuar -->
                <button 
                  type="button" 
                  class="btn btn-primary"
                  [disabled]="usernameField.invalid"
                  (click)="continueToPassword()">
                  Continuar
                </button>
              }

              <!-- Paso 2: Contraseña -->
              @if (currentStep() === 'password') {
                <!-- Mostrar usuario seleccionado -->
                <div style="background-color: var(--gris-claro); padding: 1rem; border-radius: 4px; margin-bottom: 1.5rem; border: 1px solid var(--gris-borde);">
                  <div style="font-size: 0.875rem; color: var(--gris-texto); margin-bottom: 0.25rem;">Usuario:</div>
                  <div style="font-weight: 600; color: var(--negro-texto);">{{credentials.username}}</div>
                  <button type="button" class="btn-link" (click)="goBack()" style="font-size: 0.75rem; margin-top: 0.5rem;">Cambiar usuario</button>
                </div>

                <!-- Campo Contraseña -->
                <div class="form-group" [class.has-error]="passwordField.invalid && passwordField.touched">
                  <label for="password" class="form-label">Contraseña</label>
                  <input 
                    type="password" 
                    id="password"
                    name="password"
                    #passwordField="ngModel"
                    class="form-control"
                    [(ngModel)]="credentials.password"
                    (focus)="clearError()"
                    placeholder="Ingresa tu contraseña"
                    required
                    minlength="3">
                  @if (passwordField.invalid && passwordField.touched) {
                    <span class="error-text">
                      @if (passwordField.errors?.['required']) {
                        <span>La contraseña es requerida</span>
                      }
                      @if (passwordField.errors?.['minlength']) {
                        <span>La contraseña debe tener al menos 3 caracteres</span>
                      }
                    </span>
                  }
                </div>

                <!-- Botón de iniciar sesión -->
                <button 
                  type="submit" 
                  class="btn btn-primary"
                  [disabled]="isLoading() || passwordField.invalid"
                  [class.loading]="isLoading()">
                  @if (!isLoading()) {
                    <span>Iniciar sesión</span>
                  }
                  @if (isLoading()) {
                    <span>
                      <span class="spinner"></span>
                      Iniciando sesión...
                    </span>
                  }
                </button>
              }
            </form>

            <!-- Enlaces adicionales - Solo mostrar en el primer paso -->
            @if (currentStep() === 'username') {
              <div class="login-links">
                <a href="#" class="forgot-link">¿Olvidaste tu usuario o quieres desbloquearlo?</a>
                
                <div class="first-time-section">
                  <div class="first-time-title">¿Eres cliente y es la primera vez que ingresas?</div>
                  <button type="button" class="btn btn-secondary">Regístrate</button>
                </div>
                
                <div class="support-section">
                  <div class="support-text">Si tienes problemas para ingresar, comunícate al:</div>
                  <div class="support-phone">02 400 9000</div>
                </div>
              </div>
            }

            <!-- Enlaces para el paso de contraseña -->
            @if (currentStep() === 'password') {
              <div class="login-links">
                <a href="#" class="forgot-link">¿Olvidaste tu contraseña?</a>
                
                <div class="support-section">
                  <div class="support-text">Si tienes problemas para ingresar, comunícate al:</div>
                  <div class="support-phone">02 400 9000</div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>

      <!-- Lado derecho - Visual/Branding -->
      <div class="login-right">
        <div class="visual-elements">
          <h2>Tu banco digital</h2>
          <p>Accede a todos nuestros servicios bancarios de forma segura y conveniente, desde cualquier lugar y en cualquier momento.</p>
        </div>
      </div>
    </div>
  `,
  styleUrl: './login.component.scss'
})
export class LoginComponent implements OnInit {
  private authService = inject(AuthService);
  private router = inject(Router);

  // Reactive signals for state management (Angular 19 pattern)
  errorMessage = signal<string>('');
  isLoading = signal<boolean>(false);
  currentStep = signal<'username' | 'password'>('username');

  // Credentials model
  credentials: LoginCredentials = {
    username: '',
    password: ''
  };

  ngOnInit() {
    // Verificar si ya está autenticado al cargar la página
    if (this.authService.isAuthenticated()) {
      this.redirectBasedOnRole();
    }
  }

  continueToPassword() {
    // Limpiar errores previos
    this.errorMessage.set('');

    // Validar que el usuario esté ingresado y sea válido
    if (!this.credentials.username || this.credentials.username.length < 3) {
      this.errorMessage.set('Por favor ingresa un usuario válido');
      return;
    }

    // Cambiar al paso de contraseña
    this.currentStep.set('password');

    // Enfocar el campo de contraseña después de un breve delay
    setTimeout(() => {
      const passwordField = document.getElementById('password');
      if (passwordField) {
        passwordField.focus();
      }
    }, 100);
  }

  goBack() {
    this.currentStep.set('username');
    this.credentials.password = '';
    this.errorMessage.set('');
  }

  login() {
    // Limpiar errores previos
    this.errorMessage.set('');

    // Validar formulario completo
    if (!this.credentials.username || this.credentials.username.length < 3) {
      this.errorMessage.set('Por favor ingresa un usuario válido');
      return;
    }

    if (!this.credentials.password || this.credentials.password.length < 3) {
      this.errorMessage.set('Por favor ingresa una contraseña válida');
      return;
    }

    this.isLoading.set(true);

    this.authService.login(this.credentials).subscribe({
      next: (response) => {
        this.isLoading.set(false);
        console.log('Login exitoso:', response);
        this.redirectBasedOnRole();
      },
      error: (error) => {
        this.isLoading.set(false);
        console.error('Error en login:', error);
        this.handleLoginError(error);
      }
    });
  }

  clearError() {
    this.errorMessage.set('');
  }

  private redirectBasedOnRole() {
    const userRole = this.authService.userRole();
    if (userRole === 'Admin') {
      this.router.navigate(['/admin']);
    } else {
      this.router.navigate(['/user']);
    }
  }

  private handleLoginError(error: any) {
    let message = 'Error de conexión. Por favor intenta nuevamente.';

    if (error.status === 401) {
      message = 'Usuario o contraseña incorrectos';
    } else if (error.status === 403) {
      message = 'Acceso denegado. Contacta al administrador.';
    } else if (error.status === 429) {
      message = 'Demasiados intentos. Intenta nuevamente en unos minutos.';
    } else if (error.status === 500) {
      message = 'Error del servidor. Intenta nuevamente más tarde.';
    } else if (error.error && error.error.message) {
      message = error.error.message;
    }

    this.errorMessage.set(message);
  }
}
