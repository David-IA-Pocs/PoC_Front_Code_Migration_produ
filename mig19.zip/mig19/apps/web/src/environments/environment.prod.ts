export const environment = {
    production: true,
    apiUrl: "https://api.produbanco.com/api",
    jwtTokenKey: "authToken",
    appName: "Produbanco - Banca en Línea",
};
