export const environment = {
    production: false,
    apiUrl: "http://localhost:3000/api",
    jwtTokenKey: "authToken",
    appName: "Produbanco - Banca en Línea",
};
