import { ApplicationConfig, provideZoneChangeDetection } from "@angular/core";
import {
    provideRouter,
    withEnabledBlockingInitialNavigation,
} from "@angular/router";
import { provideHttpClient, withInterceptors } from "@angular/common/http";
import { routes } from "./app.routes";
import { authInterceptor } from "@core/http/auth.interceptor";
import { coreProviders } from "@core/core.providers";

export const appConfig: ApplicationConfig = {
    providers: [
        provideZoneChangeDetection({ eventCoalescing: true }),
        provideRouter(routes, withEnabledBlockingInitialNavigation()),
        provideHttpClient(withInterceptors([authInterceptor])),
        ...coreProviders,
    ],
};
