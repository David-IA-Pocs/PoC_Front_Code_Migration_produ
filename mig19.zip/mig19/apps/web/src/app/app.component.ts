import { Component } from "@angular/core";
import { RouterOutlet } from "@angular/router";
import { NavbarComponent } from "@shared/components/navbar/navbar.component";

@Component({
    selector: "app-root",
    standalone: true,
    imports: [RouterOutlet, NavbarComponent],
    template: `
        <div class="container">
            <app-navbar />
            <main class="main-content">
                <router-outlet />
            </main>
        </div>
    `,
    styles: [
        `
            .container {
                min-height: 100vh;
                display: flex;
                flex-direction: column;
                background: var(--background-primary);
            }

            .main-content {
                flex: 1;
                display: flex;
                justify-content: center;
                align-items: center;
                padding: 0;
                min-height: calc(100vh - 80px);
            }
        `,
    ],
})
export class AppComponent {
    title = "Produbanco - Banca en Línea";
}
