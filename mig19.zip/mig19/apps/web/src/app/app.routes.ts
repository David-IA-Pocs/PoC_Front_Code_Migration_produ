import { Routes } from "@angular/router";
import { authGuard } from "@core/auth/auth.guard";
import { roleGuard } from "@core/auth/role.guard";

export const routes: Routes = [
    {
        path: "",
        redirectTo: "/login",
        pathMatch: "full",
    },
    {
        path: "login",
        loadComponent: () =>
            import("@features/auth/pages/login/login.component").then(
                (m) => m.LoginComponent
            ),
    },
    {
        path: "user",
        loadComponent: () =>
            import(
                "@features/dashboard/pages/user-dashboard/user-dashboard.component"
            ).then((m) => m.UserDashboardComponent),
        canActivate: [authGuard, roleGuard],
        data: { expectedRole: "User" },
    },
    {
        path: "admin",
        loadComponent: () =>
            import(
                "@features/dashboard/pages/admin-dashboard/admin-dashboard.component"
            ).then((m) => m.AdminDashboardComponent),
        canActivate: [authGuard, roleGuard],
        data: { expectedRole: "Admin" },
    },
    {
        path: "create-savings",
        loadComponent: () =>
            import(
                "@features/savings/pages/create-savings/create-savings.component"
            ).then((m) => m.CreateSavingsComponent),
        canActivate: [authGuard],
    },
    {
        path: "savings-accounts",
        loadComponent: () =>
            import(
                "@features/savings/pages/savings-list/savings-list.component"
            ).then((m) => m.SavingsListComponent),
        canActivate: [authGuard],
    },
    {
        path: "error",
        loadComponent: () =>
            import("@features/error/error.component").then(
                (m) => m.ErrorComponent
            ),
    },
    {
        path: "**",
        redirectTo: "/login",
    },
];
